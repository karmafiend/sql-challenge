CREATE TABLE departments(
    dept_no varchar(30) Primary Key,
    dept_name varchar(30) NOT NULL
);