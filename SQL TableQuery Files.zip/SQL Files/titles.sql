CREATE TABLE titles(
    title_id varchar(30) Primary Key,
    title varchar(30) NOT NULL
);