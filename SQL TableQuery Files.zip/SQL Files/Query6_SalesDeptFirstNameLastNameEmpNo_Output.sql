SELECT
    d.dept_name,
	e.emp_no,
	e.first_name,
    e.last_name
FROM employees e
JOIN department_employee de ON e.emp_no = de.emp_no
JOIN departments d ON de.dept_no = d.dept_no
WHERE d.dept_name = 'Sales';

	