CREATE TABLE department_manager(
   	dept_no varchar(30) NOT NULL,
	emp_no int NOT NULL,
    PRIMARY KEY (emp_no, dept_no), 
    FOREIGN KEY (dept_no) REFERENCES departments(dept_no) 
);