CREATE TABLE salaries(
    salary_id SERIAL Primary Key,
    emp_no int NOT NULL,
    salary int NOT NULL,
    FOREIGN KEY (emp_no) REFERENCES employees(emp_no)
);