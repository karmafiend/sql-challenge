CREATE TABLE employees(
    emp_no int Primary Key,
    emp_title_id varchar(30),
    birth_date date NOT NULL, 
    first_name varchar(30) NOT NULL,
    last_name varchar(30) NOT NULL,
    sex varchar(30),
    hire_date date NOT NULL
);