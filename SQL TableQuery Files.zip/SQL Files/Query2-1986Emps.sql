SELECT 
    e.first_name,
    e.last_name,
    e.hire_date 
FROM
    employees e

WHERE EXTRACT(YEAR FROM hire_date) = 1986;